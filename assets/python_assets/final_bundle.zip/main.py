import flask
from flask import request, jsonify
import sys
import io
from contextlib import redirect_stdout, redirect_stderr

# Initialize the Flask app
app = flask.Flask(__name__)

# This is the main endpoint your Flutter app will call
@app.route("/execute", methods=["POST"])
def execute():
    # Get the Python code from the request
    code = request.form.get('code', '')

    # Create in-memory "files" to capture output
    f_stdout = io.StringIO()
    f_stderr = io.StringIO()

    # Redirect both stdout (for print) and stderr (for errors)
    with redirect_stdout(f_stdout):
      with redirect_stderr(f_stderr):
        try:
            # Execute the user's code
            exec(code)
        except Exception as e:
            # If the code crashes, print the error to stderr
            print(str(e), file=sys.stderr)

    # Get the captured output from the in-memory files
    stdout_val = f_stdout.getvalue()
    stderr_val = f_stderr.getvalue()
    
    # Return both output and error as a JSON response
    return jsonify({"output": stdout_val, "error": stderr_val})

# --- THIS IS THE CRITICAL FIX ---
# We run the app directly at the global level.
# It is NOT inside an 'if' block.
print("Starting Flask server on port 5000...")
app.run(host='0.0.0.0', port=5000)